			<div class="clear"></div>
		</div>
		<div id="footer">
		&copy; <?php echo date("Y");?> - <?php bloginfo('name'); ?> is proudly powered by <a href="http://wordpress.org/">WordPress</a><br/>
		<?php /*Please leave 1 credit line to the theme designer. Thanks.*/ theme_credit();?>
		</div>
	</div>
</div></div>
<?php wp_footer(); ?>
</body>
</html>
